from flask import Flask, jsonify, request
from flask_cors import CORS
import logging
import json
from datetime import datetime, timedelta
import sys
import os
from functools import wraps
import time

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import Config
from database.database_manager import DatabaseManager

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Initialize database
db_manager = DatabaseManager(Config.DATABASE_PATH)

# Setup logging
logging.basicConfig(
    level=getattr(logging, Config.LOG_LEVEL),
    format=Config.LOG_FORMAT,
    handlers=[
        logging.FileHandler('logs/api.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Rate limiting dictionary
request_counts = {}

def rate_limit(max_requests=Config.RATE_LIMIT_REQUESTS, window=Config.RATE_LIMIT_WINDOW):
    """Rate limiting decorator"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Get client IP
            client_ip = request.environ.get('HTTP_X_FORWARDED_FOR', request.environ.get('REMOTE_ADDR', 'unknown'))
            current_time = time.time()

            # Clean old requests
            cutoff_time = current_time - window
            request_counts[client_ip] = [req_time for req_time in request_counts.get(client_ip, []) if req_time > cutoff_time]

            # Check rate limit
            if len(request_counts.get(client_ip, [])) >= max_requests:
                return jsonify({
                    'error': 'Rate limit exceeded',
                    'message': f'Maximum {max_requests} requests per {window} seconds'
                }), 429

            # Add current request
            if client_ip not in request_counts:
                request_counts[client_ip] = []
            request_counts[client_ip].append(current_time)

            return f(*args, **kwargs)
        return decorated_function
    return decorator

def log_request():
    """Log API request"""
    try:
        client_ip = request.environ.get('HTTP_X_FORWARDED_FOR', request.environ.get('REMOTE_ADDR', 'unknown'))
        user_agent = request.headers.get('User-Agent', 'unknown')

        db_manager.log_api_request(
            endpoint=request.endpoint or 'unknown',
            method=request.method,
            ip_address=client_ip,
            user_agent=user_agent,
            status=200  # Will be updated if error occurs
        )
    except Exception as e:
        logger.error(f"Error logging request: {e}")

@app.before_request
def before_request():
    """Execute before each request"""
    log_request()

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        'error': 'Not found',
        'message': 'The requested endpoint does not exist'
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        'error': 'Internal server error',
        'message': 'An unexpected error occurred'
    }), 500

@app.route('/api/status', methods=['GET'])
@rate_limit()
def api_status():
    """API health check endpoint"""
    try:
        # Check database connectivity
        current_stocks = db_manager.get_current_stocks()
        current_weather = db_manager.get_current_weather()

        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'database': {
                'connected': True,
                'total_stock_records': len(current_stocks),
                'active_weather_events': len(current_weather)
            },
            'version': '1.0.0',
            'endpoints': [
                '/api/status',
                '/api/stocks/seeds',
                '/api/stocks/gear',
                '/api/stocks/pets',
                '/api/stocks/honey',
                '/api/stocks/all',
                '/api/weather/current',
                '/api/weather/history'
            ]
        })

    except Exception as e:
        logger.error(f"Error in status endpoint: {e}")
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/stocks/seeds', methods=['GET'])
@rate_limit()
def get_seed_stocks():
    """Get seed shop stocks"""
    try:
        stocks = db_manager.get_current_stocks('seeds')

        return jsonify({
            'shop_type': 'seeds',
            'refresh_interval_minutes': Config.SEED_SHOP_INTERVAL,
            'last_updated': stocks[0]['last_updated'] if stocks else None,
            'total_items': len(stocks),
            'available_items': len([s for s in stocks if s['is_available']]),
            'items': stocks,
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Error fetching seed stocks: {e}")
        return jsonify({'error': 'Failed to fetch seed stocks'}), 500

@app.route('/api/stocks/gear', methods=['GET'])
@rate_limit()
def get_gear_stocks():
    """Get gear shop stocks"""
    try:
        stocks = db_manager.get_current_stocks('gear')

        return jsonify({
            'shop_type': 'gear',
            'refresh_interval_minutes': Config.GEAR_SHOP_INTERVAL,
            'last_updated': stocks[0]['last_updated'] if stocks else None,
            'total_items': len(stocks),
            'available_items': len([s for s in stocks if s['is_available']]),
            'items': stocks,
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Error fetching gear stocks: {e}")
        return jsonify({'error': 'Failed to fetch gear stocks'}), 500

@app.route('/api/stocks/pets', methods=['GET'])
@rate_limit()
def get_pet_stocks():
    """Get pet shop stocks"""
    try:
        stocks = db_manager.get_current_stocks('pets')

        return jsonify({
            'shop_type': 'pets',
            'refresh_interval_minutes': Config.PET_SHOP_INTERVAL,
            'last_updated': stocks[0]['last_updated'] if stocks else None,
            'total_items': len(stocks),
            'available_items': len([s for s in stocks if s['is_available']]),
            'items': stocks,
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Error fetching pet stocks: {e}")
        return jsonify({'error': 'Failed to fetch pet stocks'}), 500

@app.route('/api/stocks/honey', methods=['GET'])
@rate_limit()
def get_honey_stocks():
    """Get honey shop stocks"""
    try:
        stocks = db_manager.get_current_stocks('honey')

        return jsonify({
            'shop_type': 'honey',
            'refresh_interval_minutes': Config.HONEY_SHOP_INTERVAL,
            'last_updated': stocks[0]['last_updated'] if stocks else None,
            'total_items': len(stocks),
            'available_items': len([s for s in stocks if s['is_available']]),
            'items': stocks,
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Error fetching honey stocks: {e}")
        return jsonify({'error': 'Failed to fetch honey stocks'}), 500

@app.route('/api/stocks/all', methods=['GET'])
@rate_limit()
def get_all_stocks():
    """Get all shop stocks"""
    try:
        all_stocks = db_manager.get_current_stocks()

        # Group by shop type
        grouped_stocks = {}
        for stock in all_stocks:
            shop_type = stock['shop_type']
            if shop_type not in grouped_stocks:
                grouped_stocks[shop_type] = []
            grouped_stocks[shop_type].append(stock)

        # Add metadata for each shop
        shop_intervals = {
            'seeds': Config.SEED_SHOP_INTERVAL,
            'gear': Config.GEAR_SHOP_INTERVAL,
            'pets': Config.PET_SHOP_INTERVAL,
            'honey': Config.HONEY_SHOP_INTERVAL
        }

        result = {}
        for shop_type, stocks in grouped_stocks.items():
            result[shop_type] = {
                'refresh_interval_minutes': shop_intervals.get(shop_type, 30),
                'last_updated': stocks[0]['last_updated'] if stocks else None,
                'total_items': len(stocks),
                'available_items': len([s for s in stocks if s['is_available']]),
                'items': stocks
            }

        return jsonify({
            'shops': result,
            'timestamp': datetime.now().isoformat(),
            'total_items': len(all_stocks)
        })

    except Exception as e:
        logger.error(f"Error fetching all stocks: {e}")
        return jsonify({'error': 'Failed to fetch stocks'}), 500

@app.route('/api/weather/current', methods=['GET'])
@rate_limit()
def get_current_weather():
    """Get current weather events"""
    try:
        weather_events = db_manager.get_current_weather()

        return jsonify({
            'active_weather': weather_events,
            'total_active_events': len(weather_events),
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Error fetching current weather: {e}")
        return jsonify({'error': 'Failed to fetch current weather'}), 500

@app.route('/api/weather/history', methods=['GET'])
@rate_limit()
def get_weather_history():
    """Get weather history"""
    try:
        # Get limit parameter from query string
        limit = request.args.get('limit', 50, type=int)
        limit = min(limit, 200)  # Cap at 200 for performance

        weather_history = db_manager.get_weather_history(limit)

        return jsonify({
            'weather_history': weather_history,
            'total_events': len(weather_history),
            'limit': limit,
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Error fetching weather history: {e}")
        return jsonify({'error': 'Failed to fetch weather history'}), 500

@app.route('/api/stocks/<shop_type>/rare', methods=['GET'])
@rate_limit()
def get_rare_items(shop_type):
    """Get rare/legendary items from specific shop"""
    try:
        if shop_type not in ['seeds', 'gear', 'pets', 'honey']:
            return jsonify({'error': 'Invalid shop type'}), 400

        stocks = db_manager.get_current_stocks(shop_type)
        rare_items = [s for s in stocks if s['item_rarity'] in ['Legendary', 'Mythical', 'Divine', 'Prismatic']]

        return jsonify({
            'shop_type': shop_type,
            'rare_items': rare_items,
            'total_rare_items': len(rare_items),
            'available_rare_items': len([s for s in rare_items if s['is_available']]),
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Error fetching rare items for {shop_type}: {e}")
        return jsonify({'error': f'Failed to fetch rare items for {shop_type}'}), 500

@app.route('/api/search', methods=['GET'])
@rate_limit()
def search_items():
    """Search for specific items across all shops"""
    try:
        query = request.args.get('q', '').strip().lower()
        if not query:
            return jsonify({'error': 'Query parameter q is required'}), 400

        all_stocks = db_manager.get_current_stocks()
        matching_items = [s for s in all_stocks if query in s['item_name'].lower()]

        return jsonify({
            'query': query,
            'matching_items': matching_items,
            'total_matches': len(matching_items),
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        logger.error(f"Error searching items: {e}")
        return jsonify({'error': 'Failed to search items'}), 500

def run_api_server():
    """Run the API server"""
    logger.info(f"Starting Grow a Garden API server on {Config.API_HOST}:{Config.API_PORT}")

    try:
        app.run(
            host=Config.API_HOST,
            port=Config.API_PORT,
            debug=Config.API_DEBUG,
            threaded=True
        )
    except Exception as e:
        logger.error(f"Error starting API server: {e}")
        raise

if __name__ == '__main__':
    run_api_server()
