# 🌱 Grow a Garden Stock Tracker API

A comprehensive REST API and scraping system for tracking stock changes, weather events, and other game mechanics in the Roblox game "Grow a Garden".

## 🚀 Features

- **Real-time Stock Tracking**: Monitor all shops (Seeds, Gear, Pets, Honey) with automatic refresh detection
- **Weather Event Detection**: Track all weather types including rare events like Blood Moon and Meteor Showers
- **REST API**: Clean JSON endpoints for integration with Discord bots or other applications
- **Database Storage**: SQLite database with full history tracking
- **Rate Limiting**: Built-in protection against API abuse
- **Discord Bot Integration**: Ready-to-use Discord bot with rich embeds and notifications
- **Anti-Detection**: Advanced web scraping with undetected Chrome driver
- **Production Ready**: Comprehensive logging, error handling, and monitoring

## 📋 Shop Refresh Intervals

- **Seeds Shop**: Every 5 minutes
- **Gear Shop**: Every 5 minutes  
- **Pet Shop**: Every 30 minutes
- **Honey Shop**: Every 30 minutes

## 🌤️ Weather Events Tracked

- **Standard Weather**: Rain, Frost, Thunderstorm (random intervals)
- **Night Events**: Every 4 hours at 30 minutes past the hour (10 minutes duration)
- **Blood Moon**: 33.33% chance to replace Night (15 minutes duration)
- **Meteor Shower**: Rare events during night time
- **Admin Events**: Disco, Jandel Storm, Chocolate Rain, etc.

## 🛠️ Installation

### Prerequisites

- Python 3.8+
- Chrome browser installed
- Roblox account with access to Grow a Garden

### Quick Setup

1. **Clone/Download** this project
2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment**:
   ```bash
   cp .env.template .env
   # Edit .env file with your credentials
   ```

4. **Run the system**:
   ```bash
   python main.py
   ```

### Detailed Setup

#### 1. Environment Configuration

Edit the `.env` file with your settings:

```env
# Required: Roblox Account
ROBLOX_USERNAME=your_roblox_username
ROBLOX_PASSWORD=your_roblox_password

# Optional: Discord Bot (for notifications)
DISCORD_TOKEN=your_discord_bot_token
DISCORD_CHANNEL_ID=your_discord_channel_id

# Optional: API Settings
API_HOST=0.0.0.0
API_PORT=5000
```

#### 2. Chrome Driver Setup

The system uses undetected Chrome driver. Make sure you have:
- Chrome browser installed
- Compatible Chrome driver (automatically downloaded)

#### 3. Database Setup

The SQLite database is automatically created on first run at:
```
database/grow_a_garden.db
```

## 🚀 Usage

### Running the Full System

```bash
python main.py
```

This starts both:
- **API Server** on `http://localhost:5000`
- **Scraper Process** that monitors the game

### Running Components Separately

**API Server Only**:
```bash
python api/api_server.py
```

**Scraper Only**:
```bash
python scrapers/roblox_scraper.py
```

**Discord Bot** (requires API running):
```bash
python examples/discord_bot.py
```

## 📡 API Endpoints

### Stock Endpoints

| Endpoint | Description | Refresh Rate |
|----------|-------------|--------------|
| `GET /api/stocks/seeds` | Seed shop stocks | 5 minutes |
| `GET /api/stocks/gear` | Gear shop stocks | 5 minutes |
| `GET /api/stocks/pets` | Pet shop stocks | 30 minutes |
| `GET /api/stocks/honey` | Honey shop stocks | 30 minutes |
| `GET /api/stocks/all` | All shop stocks | Combined |

### Weather Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/weather/current` | Active weather events |
| `GET /api/weather/history?limit=50` | Weather history |

### Utility Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/status` | API health check |
| `GET /api/search?q=grape` | Search items |
| `GET /api/stocks/{shop}/rare` | Get rare items only |

### Example API Response

```json
{
  "shop_type": "seeds",
  "refresh_interval_minutes": 5,
  "last_updated": "2025-01-15T10:30:00Z",
  "total_items": 19,
  "available_items": 15,
  "items": [
    {
      "id": 1,
      "shop_type": "seeds",
      "item_name": "Grape Seed",
      "item_rarity": "Divine",
      "stock_count": 2,
      "price": 1000,
      "currency": "coins",
      "is_available": true,
      "timestamp": "2025-01-15T10:30:00Z"
    }
  ],
  "timestamp": "2025-01-15T10:35:00Z"
}
```

## 🤖 Discord Bot Commands

| Command | Description |
|---------|-------------|
| `!stocks [shop]` | Get current stocks (`all`, `seeds`, `gear`, `pets`, `honey`) |
| `!weather` | Get current weather |
| `!search <item>` | Search for specific items |
| `!status` | Check API health |

### Discord Bot Features

- **Automatic Notifications**: Alerts for rare items and weather events
- **Rich Embeds**: Beautiful formatted messages with colors and emojis
- **Role Mentions**: Configurable pings for Divine/Prismatic items
- **Real-time Updates**: Monitors API every 1-2 minutes

## 🏗️ Project Structure

```
grow-a-garden-tracker/
├── main.py                 # Main application runner
├── requirements.txt        # Python dependencies
├── .env.template          # Environment template
├── README.md             # This file
│
├── api/
│   └── api_server.py     # Flask REST API server
│
├── config/
│   └── config.py         # Configuration management
│
├── database/
│   ├── database_manager.py  # Database operations
│   └── grow_a_garden.db     # SQLite database (auto-created)
│
├── scrapers/
│   └── roblox_scraper.py    # Game scraping logic
│
├── examples/
│   └── discord_bot.py       # Discord bot integration
│
└── logs/                    # Application logs
    ├── main.log
    ├── api.log
    └── scraper.log
```

## ⚙️ Configuration Options

### config/config.py

Key settings you can modify:

```python
class Config:
    # Scraper settings
    SCRAPER_DELAY = 30  # seconds between checks
    SELENIUM_TIMEOUT = 30

    # API settings
    API_HOST = '0.0.0.0'
    API_PORT = 5000

    # Rate limiting
    RATE_LIMIT_REQUESTS = 100  # per hour

    # Chrome options
    CHROME_OPTIONS = [
        '--no-sandbox',
        '--disable-dev-shm-usage',
        # ... more options
    ]
```

## 🚀 Cloud Deployment

### Oracle Cloud (Free Forever)

1. **Create Oracle Cloud account**
2. **Launch Ubuntu instance** (ARM - 4 OCPU, 24GB RAM free)
3. **Install dependencies**:
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip

   # Install Chrome
   wget -q -O - https://dl.google.com/linux/linux_signing_key.pub | sudo apt-key add -
   sudo sh -c 'echo "deb https://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google-chrome.list'
   sudo apt update
   sudo apt install google-chrome-stable
   ```

4. **Deploy application**:
   ```bash
   git clone <your-repo>
   cd grow-a-garden-tracker
   pip3 install -r requirements.txt

   # Configure .env file
   cp .env.template .env
   nano .env

   # Run with screen/tmux
   screen -S grow-garden
   python3 main.py
   ```

### Alternative Hosting

- **AWS Free Tier**: 1 year free (t2.micro)
- **Google Cloud**: $300 credit
- **DigitalOcean**: $200 credit
- **Heroku**: Free tier (with limitations)

## 🛡️ Security & Best Practices

### Rate Limiting
- 100 requests per hour per IP
- Configurable limits
- Automatic cleanup of old requests

### Anti-Detection
- Undetected Chrome driver
- Random user agents
- Realistic delays between requests
- Request header spoofing

### Data Protection
- Local SQLite database
- No sensitive data in logs
- Environment variable protection

### Error Handling
- Comprehensive try-catch blocks
- Automatic reconnection logic
- Graceful degradation
- Detailed logging

## 📊 Monitoring & Logs

### Log Files
- `logs/main.log` - Main application events
- `logs/api.log` - API requests and responses  
- `logs/scraper.log` - Scraping activities and errors

### Health Checks
- `/api/status` endpoint
- Database connectivity checks
- Process monitoring
- Error rate tracking

## 🔧 Troubleshooting

### Common Issues

**Chrome Driver Issues**:
```bash
# Update Chrome
sudo apt update && sudo apt upgrade google-chrome-stable

# Clear driver cache
rm -rf ~/.cache/selenium
```

**Database Locks**:
```bash
# Check for hung processes
ps aux | grep python
kill -9 <process_id>
```

**Login Failures**:
- Check Roblox credentials in `.env`
- Verify 2FA is disabled
- Check for CAPTCHA requirements
- Use alternate account

**Memory Issues**:
```bash
# Monitor memory usage
htop

# Increase swap space (cloud servers)
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

### Performance Optimization

**Reduce Resource Usage**:
```python
# In config.py, modify:
CHROME_OPTIONS = [
    '--headless',           # Run headless
    '--no-sandbox',
    '--disable-dev-shm-usage',
    '--disable-gpu',
    '--memory-pressure-off',
    '--single-process'      # Use single process
]

SCRAPER_DELAY = 60  # Increase delay between checks
```

**Database Optimization**:
```sql
-- Regular cleanup (run monthly)
DELETE FROM api_logs WHERE timestamp < datetime('now', '-30 days');
DELETE FROM weather WHERE start_time < datetime('now', '-7 days') AND is_active = 0;
VACUUM;  -- Reclaim space
```

## 🤝 Contributing

### Development Setup

1. **Fork the repository**
2. **Create feature branch**: `git checkout -b feature/new-feature`
3. **Install dev dependencies**: `pip install -r requirements-dev.txt`
4. **Run tests**: `python -m pytest`
5. **Submit pull request**

### Code Style
- Follow PEP 8
- Use type hints where possible  
- Add docstrings to functions
- Include error handling

### Testing
```bash
# Run all tests
python -m pytest

# Run specific test
python -m pytest tests/test_api.py

# Run with coverage
python -m pytest --cov=.
```

## 📜 License

This project is for educational purposes only. Please respect Roblox's Terms of Service.

## ⚠️ Disclaimer

- **Use at your own risk** - Automation may violate Roblox ToS
- **No warranty** - Software provided as-is
- **Educational purpose** - Learn web scraping and API development
- **Respect rate limits** - Don't overload Roblox servers

## 🆘 Support

### Getting Help

1. **Check logs** in `logs/` directory
2. **Verify configuration** in `.env` file
3. **Test API endpoints** with curl/browser
4. **Check system resources** (memory, disk space)

### Reporting Issues

Include in your report:
- Operating system
- Python version
- Error messages from logs
- Steps to reproduce
- Configuration (without sensitive data)

### Example Commands for Testing

```bash
# Test API endpoints
curl http://localhost:5000/api/status
curl http://localhost:5000/api/stocks/seeds
curl http://localhost:5000/api/weather/current

# Check processes
ps aux | grep python

# Monitor logs
tail -f logs/main.log
tail -f logs/api.log
tail -f logs/scraper.log

# Test database
sqlite3 database/grow_a_garden.db ".tables"
sqlite3 database/grow_a_garden.db "SELECT COUNT(*) FROM stocks;"
```

---

**Happy tracking! 🌱📊**

*May your gardens always have rare seeds in stock!*
