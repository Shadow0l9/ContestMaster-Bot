#!/usr/bin/env python3
"""
Simple test script to verify the Grow a Garden API is working
"""

import requests
import json
import time
import sys

API_BASE_URL = "http://localhost:5000/api"

def test_endpoint(endpoint, description):
    """Test a single API endpoint"""
    print(f"Testing {description}...")
    try:
        response = requests.get(f"{API_BASE_URL}{endpoint}", timeout=10)

        if response.status_code == 200:
            data = response.json()
            print(f"  ✅ SUCCESS - {len(str(data))} bytes returned")
            return True
        else:
            print(f"  ❌ FAILED - Status: {response.status_code}")
            return False

    except requests.exceptions.ConnectionError:
        print(f"  ❌ FAILED - Connection refused (is the API server running?)")
        return False
    except Exception as e:
        print(f"  ❌ FAILED - Error: {e}")
        return False

def main():
    print("="*50)
    print("Grow a Garden API Test Suite")
    print("="*50)
    print()

    # Test endpoints
    tests = [
        ("/status", "API Status"),
        ("/stocks/seeds", "Seed Shop Stocks"),
        ("/stocks/gear", "Gear Shop Stocks"), 
        ("/stocks/pets", "Pet Shop Stocks"),
        ("/stocks/honey", "Honey Shop Stocks"),
        ("/stocks/all", "All Shop Stocks"),
        ("/weather/current", "Current Weather"),
        ("/weather/history", "Weather History"),
        ("/search?q=grape", "Item Search")
    ]

    passed = 0
    total = len(tests)

    for endpoint, description in tests:
        if test_endpoint(endpoint, description):
            passed += 1
        time.sleep(0.5)  # Small delay between tests

    print()
    print("="*50)
    print(f"Test Results: {passed}/{total} tests passed")

    if passed == total:
        print("🎉 All tests passed! API is working correctly.")
        sys.exit(0)
    else:
        print("⚠️  Some tests failed. Check the API server and database.")
        sys.exit(1)

if __name__ == "__main__":
    main()
