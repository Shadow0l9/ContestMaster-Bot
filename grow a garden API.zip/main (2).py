#!/usr/bin/env python3
"""
Grow a Garden Stock Tracker - Main Application
This script starts both the scraper and API server in separate processes
"""

import multiprocessing
import sys
import os
import time
import logging
from pathlib import Path

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from config.config import Config
from scrapers.roblox_scraper import RobloxScraper
from api.api_server import run_api_server
from database.database_manager import DatabaseManager

def setup_logging():
    """Setup logging for main application"""
    Path('logs').mkdir(exist_ok=True)

    logging.basicConfig(
        level=getattr(logging, Config.LOG_LEVEL),
        format=Config.LOG_FORMAT,
        handlers=[
            logging.FileHandler('logs/main.log'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def run_scraper():
    """Run the scraper in a separate process"""
    try:
        logger = logging.getLogger('scraper_process')
        logger.info("Starting scraper process...")

        # Initialize database
        db_manager = DatabaseManager(Config.DATABASE_PATH)

        # Initialize and run scraper
        scraper = RobloxScraper(db_manager)
        scraper.run_continuous()

    except Exception as e:
        logger.error(f"Scraper process error: {e}")
        raise

def run_api():
    """Run the API server in a separate process"""
    try:
        logger = logging.getLogger('api_process')
        logger.info("Starting API server process...")

        run_api_server()

    except Exception as e:
        logger.error(f"API server process error: {e}")
        raise

def main():
    """Main function to start both processes"""
    logger = setup_logging()

    logger.info("="*50)
    logger.info("Starting Grow a Garden Stock Tracker")
    logger.info("="*50)

    # Check configuration
    if not Config.ROBLOX_USERNAME or not Config.ROBLOX_PASSWORD:
        logger.error("Please set ROBLOX_USERNAME and ROBLOX_PASSWORD in your .env file")
        sys.exit(1)

    # Initialize database
    logger.info("Initializing database...")
    try:
        db_manager = DatabaseManager(Config.DATABASE_PATH)
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        sys.exit(1)

    # Create processes
    processes = []

    try:
        # Start API server process
        logger.info("Starting API server process...")
        api_process = multiprocessing.Process(target=run_api, name="API-Server")
        api_process.start()
        processes.append(api_process)

        # Wait a moment for API to start
        time.sleep(2)

        # Start scraper process
        logger.info("Starting scraper process...")
        scraper_process = multiprocessing.Process(target=run_scraper, name="Roblox-Scraper")
        scraper_process.start()
        processes.append(scraper_process)

        logger.info("Both processes started successfully!")
        logger.info(f"API server running on http://{Config.API_HOST}:{Config.API_PORT}")
        logger.info("Press Ctrl+C to stop all processes")

        # Wait for processes
        for process in processes:
            process.join()

    except KeyboardInterrupt:
        logger.info("Received shutdown signal...")

        # Terminate all processes
        for process in processes:
            if process.is_alive():
                logger.info(f"Terminating {process.name}...")
                process.terminate()
                process.join(timeout=5)

                if process.is_alive():
                    logger.warning(f"Force killing {process.name}...")
                    process.kill()

        logger.info("All processes stopped.")

    except Exception as e:
        logger.error(f"Unexpected error: {e}")

        # Cleanup processes
        for process in processes:
            if process.is_alive():
                process.terminate()

        sys.exit(1)

if __name__ == "__main__":
    # Set multiprocessing start method for compatibility
    if sys.platform != 'win32':
        multiprocessing.set_start_method('spawn', force=True)

    main()
