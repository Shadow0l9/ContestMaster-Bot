# 🌱 Grow a Garden Stock Tracker - Complete System

## 📁 Project Files Created

### Core Application Files
- **`main.py`** - Main application runner that launches both API server and scraper
- **`requirements.txt`** - Python package dependencies
- **`.env.template`** - Environment configuration template
- **`start.sh`** - Bash script for easy setup and deployment (executable)
- **`test_api.py`** - API testing script to verify endpoints work

### API Server (`/api/`)
- **`api_server.py`** - Flask REST API server with all endpoints
- **`__init__.py`** - Python module marker

### Configuration (`/config/`)
- **`config.py`** - Centralized configuration management
- **`__init__.py`** - Python module marker

### Database (`/database/`)
- **`database_manager.py`** - SQLite database operations and schema
- **`__init__.py`** - Python module marker
- **`grow_a_garden.db`** - SQLite database (auto-created on first run)

### Web Scraper (`/scrapers/`)
- **`roblox_scraper.py`** - Selenium-based game scraper with anti-detection
- **`__init__.py`** - Python module marker

### Examples (`/examples/`)
- **`discord_bot.py`** - Complete Discord bot with commands and notifications
- **`__init__.py`** - Python module marker

### Auto-Generated Directories
- **`logs/`** - Application log files (created automatically)
- **`database/`** - Database storage directory

## 🚀 Quick Start Commands

```bash
# First time setup (installs dependencies, creates config)
./start.sh setup

# Edit configuration with your Roblox credentials
nano .env

# Run the complete system (API + Scraper)
./start.sh run

# Test that the API is working
./start.sh test

# Run Discord bot (optional, requires Discord token)
./start.sh discord
```

## 📡 API Endpoints Available

Once running, the API will be available at `http://localhost:5000/api/`

### Stock Endpoints
- `GET /api/stocks/seeds` - Seed shop inventory
- `GET /api/stocks/gear` - Gear shop inventory  
- `GET /api/stocks/pets` - Pet shop inventory
- `GET /api/stocks/honey` - Honey shop inventory
- `GET /api/stocks/all` - All shop inventories combined
- `GET /api/stocks/{shop}/rare` - Only rare items from specific shop

### Weather Endpoints
- `GET /api/weather/current` - Active weather events
- `GET /api/weather/history?limit=50` - Weather event history

### Utility Endpoints
- `GET /api/status` - API health check and statistics
- `GET /api/search?q=grape` - Search for items by name

## 🤖 Discord Bot Commands

When using the Discord bot (`./start.sh discord`):

- `!stocks [shop]` - Get current stock info (all/seeds/gear/pets/honey)
- `!weather` - Get current weather information
- `!search <query>` - Search for specific items
- `!status` - Check API health and database stats

## 🛠️ System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Roblox Game   │◄───│  Web Scraper    │───►│   SQLite DB     │
│  (Grow Garden)  │    │  (Selenium)     │    │  (Data Store)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                ▲                       ▲
                                │                       │
                                ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Discord Bot   │◄───│   Flask API     │◄───│  Your Bot/App   │
│  (Notifications)│    │  (REST Server)  │    │  (HTTP Client)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🏗️ Key Features Implemented

### ✅ Stock Tracking
- All 4 shops monitored (Seeds, Gear, Pets, Honey)
- Proper refresh intervals (5min for seeds/gear, 30min for pets/honey)
- Stock levels, prices, and availability tracking
- Rare item detection (Legendary, Mythical, Divine, Prismatic)

### ✅ Weather Monitoring  
- All weather types tracked (Rain, Frost, Night, Blood Moon, etc.)
- Weather event history with duration tracking
- Mutation possibilities documented

### ✅ Anti-Detection Measures
- Undetected Chrome driver
- Random user agents and delays
- Realistic browsing patterns
- Error handling and reconnection logic

### ✅ Production Ready
- Comprehensive logging system
- Rate limiting for API protection
- Multi-process architecture
- Graceful error handling and recovery
- Health monitoring endpoints

### ✅ Easy Deployment
- One-command setup script
- Cloud deployment instructions (Oracle, AWS, etc.)
- Docker-ready architecture
- Environment-based configuration

## 🔧 Configuration Options

Edit `.env` file for your setup:

```env
# Required - Your Roblox account
ROBLOX_USERNAME=your_username_here
ROBLOX_PASSWORD=your_password_here

# Optional - Discord integration
DISCORD_TOKEN=your_bot_token_here
DISCORD_CHANNEL_ID=123456789012345678

# Optional - API settings
API_HOST=0.0.0.0
API_PORT=5000
```

## 📊 Example API Response

```json
{
  "shop_type": "seeds",
  "refresh_interval_minutes": 5,
  "last_updated": "2025-01-15T10:30:00Z",
  "total_items": 19,
  "available_items": 15,
  "items": [
    {
      "shop_type": "seeds",
      "item_name": "Dragon Fruit Seed",
      "item_rarity": "Mythical",
      "stock_count": 3,
      "price": 600,
      "currency": "coins",
      "is_available": true,
      "timestamp": "2025-01-15T10:30:00Z"
    }
  ],
  "timestamp": "2025-01-15T10:35:00Z"
}
```

## 🚨 Important Notes

### Legal & ToS Compliance
- **Educational Use Only**: This system is for learning web scraping and API development
- **Roblox ToS**: Automation may violate Terms of Service - use at your own risk
- **Rate Limiting**: Built-in delays and limits to respect Roblox servers
- **No Monetization**: Don't sell or profit from scraped data

### Security Best Practices
- **Alt Accounts**: Use alternate Roblox accounts to protect your main account
- **Environment Variables**: Keep credentials in `.env` file, never in code
- **Rate Limits**: API has built-in rate limiting (100 requests/hour by default)
- **Local Database**: All data stored locally in SQLite

### Performance Considerations
- **Memory Usage**: Chrome driver can use significant RAM (~500MB+)
- **Network Usage**: Continuous scraping uses internet bandwidth
- **Cloud Hosting**: Oracle Cloud free tier recommended (4 CPU, 24GB RAM)
- **Monitoring**: Check logs regularly for errors and performance

## 📈 Future Enhancement Ideas

- **Mobile App**: React Native app using the API
- **Web Dashboard**: Real-time web interface with charts
- **Telegram Bot**: Alternative to Discord notifications
- **Data Analytics**: Price history and trend analysis
- **Multi-Account**: Support for multiple Roblox accounts
- **Push Notifications**: Mobile push alerts for rare items
- **Trading Integration**: Price comparison with trading platforms

## 🆘 Troubleshooting

### Common Issues & Solutions

**API Not Responding**:
```bash
# Check if process is running
ps aux | grep python

# Check logs
tail -f logs/api.log

# Restart API server
./start.sh api
```

**Scraper Login Failed**:
- Verify credentials in `.env`
- Disable 2FA on Roblox account
- Use alternate account
- Check for CAPTCHA requirements

**Chrome Driver Issues**:
```bash
# Update Chrome browser
sudo apt update && sudo apt upgrade google-chrome-stable

# Clear Selenium cache  
rm -rf ~/.cache/selenium
```

**Database Locked**:
```bash
# Kill hung processes
ps aux | grep python | grep -v grep | awk '{print $2}' | xargs kill

# Restart application
./start.sh run
```

**Discord Bot Not Working**:
- Verify `DISCORD_TOKEN` in `.env`
- Check `DISCORD_CHANNEL_ID` is correct
- Ensure bot has proper permissions
- API must be running first

### Getting Help

1. **Check Logs**: All issues are logged in `logs/` directory
2. **Test API**: Use `./start.sh test` to verify endpoints
3. **Verify Config**: Ensure `.env` has correct values
4. **Resource Check**: Monitor CPU/memory usage with `htop`
5. **Network Check**: Ensure internet connection and Roblox access

## 🎉 Success Indicators

Your system is working correctly when you see:

✅ **API Status**: `curl http://localhost:5000/api/status` returns healthy  
✅ **Stock Data**: API endpoints return current shop inventories  
✅ **Weather Data**: Weather events are being tracked  
✅ **Database**: SQLite file grows with data over time  
✅ **Logs**: Clean log entries without repeated errors  
✅ **Discord**: Bot sends notifications for rare items/weather  

## 📞 Support

This is a complete, production-ready system for tracking Grow a Garden stocks and weather. The API provides all the endpoints your Discord bot script needs to function properly.

The system handles:
- ✅ All shop monitoring with proper refresh intervals
- ✅ Weather event detection and tracking  
- ✅ Rate limiting and anti-detection measures
- ✅ Production-ready logging and error handling
- ✅ Easy deployment and configuration
- ✅ Complete Discord bot integration example

**Your Discord bot can now use these API endpoint URLs in your existing script!**

---

*Happy gardening and may your stocks always have rare seeds! 🌱✨*
