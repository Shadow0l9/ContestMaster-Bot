import discord
from discord.ext import commands, tasks
import aiohttp
import asyncio
import json
import logging
from datetime import datetime
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import Config

# Bot configuration
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StockNotifier:
    def __init__(self, bot):
        self.bot = bot
        self.api_base_url = Config.API_BASE_URL
        self.session = None
        self.previous_stocks = {}
        self.previous_weather = []

    async def init_session(self):
        """Initialize aiohttp session"""
        if not self.session:
            self.session = aiohttp.ClientSession()

    async def close_session(self):
        """Close aiohttp session"""
        if self.session:
            await self.session.close()

    async def fetch_api_data(self, endpoint):
        """Fetch data from API endpoint"""
        try:
            await self.init_session()
            async with self.session.get(f"{self.api_base_url}{endpoint}") as response:
                if response.status == 200:
                    return await response.json()
                else:
                    logger.error(f"API request failed: {response.status}")
                    return None
        except Exception as e:
            logger.error(f"Error fetching data from {endpoint}: {e}")
            return None

    async def check_stock_changes(self):
        """Check for stock changes and send notifications"""
        try:
            # Fetch all stocks
            stocks_data = await self.fetch_api_data('/stocks/all')
            if not stocks_data:
                return

            # Check each shop for changes
            for shop_type, shop_data in stocks_data.get('shops', {}).items():
                await self.check_shop_changes(shop_type, shop_data)

        except Exception as e:
            logger.error(f"Error checking stock changes: {e}")

    async def check_shop_changes(self, shop_type, shop_data):
        """Check changes for a specific shop"""
        try:
            current_items = {item['item_name']: item for item in shop_data.get('items', [])}
            previous_items = self.previous_stocks.get(shop_type, {})

            # Find new rare items in stock
            new_rare_items = []
            for item_name, item_data in current_items.items():
                if (item_data.get('item_rarity') in ['Legendary', 'Mythical', 'Divine', 'Prismatic'] and
                    item_data.get('is_available') and
                    (item_name not in previous_items or not previous_items[item_name].get('is_available'))):
                    new_rare_items.append(item_data)

            # Send notifications for new rare items
            if new_rare_items:
                await self.send_rare_items_notification(shop_type, new_rare_items)

            # Update previous stocks
            self.previous_stocks[shop_type] = current_items

        except Exception as e:
            logger.error(f"Error checking {shop_type} shop changes: {e}")

    async def check_weather_changes(self):
        """Check for weather changes"""
        try:
            weather_data = await self.fetch_api_data('/weather/current')
            if not weather_data:
                return

            current_weather = weather_data.get('active_weather', [])

            # Find new weather events
            new_weather = []
            previous_weather_types = [w.get('weather_type') for w in self.previous_weather]

            for weather in current_weather:
                if weather.get('weather_type') not in previous_weather_types:
                    new_weather.append(weather)

            # Send notifications for new weather
            if new_weather:
                await self.send_weather_notification(new_weather)

            self.previous_weather = current_weather

        except Exception as e:
            logger.error(f"Error checking weather changes: {e}")

    async def send_rare_items_notification(self, shop_type, items):
        """Send notification for rare items"""
        try:
            channel_id = int(Config.DISCORD_CHANNEL_ID)
            channel = self.bot.get_channel(channel_id)

            if not channel:
                logger.error(f"Could not find channel with ID: {channel_id}")
                return

            # Create embed
            embed = discord.Embed(
                title=f"🌟 Rare Items in {shop_type.title()} Shop!",
                color=discord.Color.gold(),
                timestamp=datetime.now()
            )

            for item in items:
                rarity_emoji = {
                    'Legendary': '🟠',
                    'Mythical': '🟣',
                    'Divine': '🔴',
                    'Prismatic': '🌈'
                }.get(item.get('item_rarity'), '⭐')

                embed.add_field(
                    name=f"{rarity_emoji} {item['item_name']}",
                    value=f"Stock: {item.get('stock_count', 0)}\nPrice: {item.get('price', 0)} coins",
                    inline=True
                )

            embed.set_footer(text="Grow a Garden Stock Tracker")

            # Send with role mentions (customize as needed)
            content = "@everyone" if any(item.get('item_rarity') in ['Divine', 'Prismatic'] for item in items) else ""

            await channel.send(content=content, embed=embed)
            logger.info(f"Sent rare items notification for {shop_type}")

        except Exception as e:
            logger.error(f"Error sending rare items notification: {e}")

    async def send_weather_notification(self, weather_events):
        """Send notification for weather events"""
        try:
            channel_id = int(Config.DISCORD_CHANNEL_ID)
            channel = self.bot.get_channel(channel_id)

            if not channel:
                logger.error(f"Could not find channel with ID: {channel_id}")
                return

            for weather in weather_events:
                weather_type = weather.get('weather_type', 'Unknown')

                # Only notify for special weather
                if weather_type in ['Night', 'Blood Moon', 'Meteor Shower', 'Thunderstorm', 'Frost']:
                    embed = discord.Embed(
                        title=f"🌤️ Weather Alert: {weather_type}",
                        color=discord.Color.blue(),
                        timestamp=datetime.now()
                    )

                    weather_descriptions = {
                        'Night': 'Moonlit mutations possible! 🌙',
                        'Blood Moon': 'Bloodlit mutations possible! 🩸',
                        'Meteor Shower': 'Celestial mutations possible! ☄️',
                        'Thunderstorm': 'Shocked mutations possible! ⚡',
                        'Frost': 'Chilled/Frozen mutations possible! ❄️'
                    }

                    description = weather_descriptions.get(weather_type, f"{weather_type} weather is active!")
                    embed.add_field(name="Effect", value=description, inline=False)
                    embed.set_footer(text="Grow a Garden Weather Tracker")

                    await channel.send(embed=embed)
                    logger.info(f"Sent weather notification for {weather_type}")

        except Exception as e:
            logger.error(f"Error sending weather notification: {e}")

# Initialize stock notifier
stock_notifier = StockNotifier(bot)

@bot.event
async def on_ready():
    """Called when bot is ready"""
    logger.info(f'{bot.user} has logged in!')

    # Start monitoring tasks
    if not stock_monitor.is_running():
        stock_monitor.start()
    if not weather_monitor.is_running():
        weather_monitor.start()

    logger.info("Monitoring tasks started")

@tasks.loop(minutes=2)  # Check every 2 minutes
async def stock_monitor():
    """Monitor stock changes"""
    await stock_notifier.check_stock_changes()

@tasks.loop(minutes=1)  # Check every minute
async def weather_monitor():
    """Monitor weather changes"""
    await stock_notifier.check_weather_changes()

@bot.command(name='stocks')
async def get_stocks(ctx, shop_type='all'):
    """Get current stock information"""
    try:
        if shop_type == 'all':
            data = await stock_notifier.fetch_api_data('/stocks/all')
            if not data:
                await ctx.send("❌ Failed to fetch stock data")
                return

            embed = discord.Embed(title="📦 All Shop Stocks", color=discord.Color.green())

            for shop, shop_data in data.get('shops', {}).items():
                available_items = shop_data.get('available_items', 0)
                total_items = shop_data.get('total_items', 0)
                embed.add_field(
                    name=f"{shop.title()} Shop",
                    value=f"{available_items}/{total_items} items available",
                    inline=True
                )
        else:
            if shop_type not in ['seeds', 'gear', 'pets', 'honey']:
                await ctx.send("❌ Invalid shop type. Use: seeds, gear, pets, honey, or all")
                return

            data = await stock_notifier.fetch_api_data(f'/stocks/{shop_type}')
            if not data:
                await ctx.send("❌ Failed to fetch stock data")
                return

            embed = discord.Embed(
                title=f"📦 {shop_type.title()} Shop Stock",
                color=discord.Color.green()
            )

            available_items = [item for item in data.get('items', []) if item.get('is_available')]
            rare_items = [item for item in available_items if item.get('item_rarity') in ['Legendary', 'Mythical', 'Divine', 'Prismatic']]

            embed.add_field(name="Total Available", value=len(available_items), inline=True)
            embed.add_field(name="Rare Items", value=len(rare_items), inline=True)

            if rare_items:
                rare_list = "\n".join([f"• {item['item_name']} ({item.get('stock_count', 0)} left)" for item in rare_items[:10]])
                embed.add_field(name="Rare Items Available", value=rare_list, inline=False)

        embed.set_footer(text="Grow a Garden Stock Tracker")
        await ctx.send(embed=embed)

    except Exception as e:
        logger.error(f"Error in stocks command: {e}")
        await ctx.send("❌ An error occurred while fetching stock data")

@bot.command(name='weather')
async def get_weather(ctx):
    """Get current weather information"""
    try:
        data = await stock_notifier.fetch_api_data('/weather/current')
        if not data:
            await ctx.send("❌ Failed to fetch weather data")
            return

        active_weather = data.get('active_weather', [])

        if not active_weather:
            embed = discord.Embed(
                title="🌤️ Current Weather",
                description="Clear weather (no special effects)",
                color=discord.Color.light_grey()
            )
        else:
            embed = discord.Embed(
                title="🌤️ Current Weather",
                color=discord.Color.blue()
            )

            for weather in active_weather:
                weather_type = weather.get('weather_type', 'Unknown')
                start_time = weather.get('start_time', 'Unknown')

                embed.add_field(
                    name=weather_type,
                    value=f"Started: {start_time}",
                    inline=False
                )

        embed.set_footer(text="Grow a Garden Weather Tracker")
        await ctx.send(embed=embed)

    except Exception as e:
        logger.error(f"Error in weather command: {e}")
        await ctx.send("❌ An error occurred while fetching weather data")

@bot.command(name='search')
async def search_items(ctx, *, query):
    """Search for specific items"""
    try:
        data = await stock_notifier.fetch_api_data(f'/search?q={query}')
        if not data:
            await ctx.send("❌ Failed to search items")
            return

        matching_items = data.get('matching_items', [])

        if not matching_items:
            await ctx.send(f"❌ No items found matching '{query}'")
            return

        embed = discord.Embed(
            title=f"🔍 Search Results for '{query}'",
            color=discord.Color.purple()
        )

        for item in matching_items[:10]:  # Limit to 10 results
            availability = "✅ Available" if item.get('is_available') else "❌ Out of Stock"
            embed.add_field(
                name=f"{item['item_name']} ({item.get('item_rarity')})",
                value=f"Shop: {item['shop_type']}\n{availability}\nPrice: {item.get('price', 0)} coins",
                inline=True
            )

        if len(matching_items) > 10:
            embed.set_footer(text=f"Showing 10 of {len(matching_items)} results")
        else:
            embed.set_footer(text=f"Found {len(matching_items)} results")

        await ctx.send(embed=embed)

    except Exception as e:
        logger.error(f"Error in search command: {e}")
        await ctx.send("❌ An error occurred while searching")

@bot.command(name='status')
async def api_status(ctx):
    """Check API status"""
    try:
        data = await stock_notifier.fetch_api_data('/status')
        if not data:
            await ctx.send("❌ API is not responding")
            return

        embed = discord.Embed(
            title="🚀 API Status",
            color=discord.Color.green() if data.get('status') == 'healthy' else discord.Color.red()
        )

        embed.add_field(name="Status", value=data.get('status', 'unknown'), inline=True)
        embed.add_field(name="Version", value=data.get('version', 'unknown'), inline=True)

        db_info = data.get('database', {})
        embed.add_field(name="Database", value="Connected" if db_info.get('connected') else "Disconnected", inline=True)
        embed.add_field(name="Stock Records", value=db_info.get('total_stock_records', 0), inline=True)
        embed.add_field(name="Active Weather", value=db_info.get('active_weather_events', 0), inline=True)

        embed.set_footer(text="Grow a Garden Stock Tracker")
        await ctx.send(embed=embed)

    except Exception as e:
        logger.error(f"Error in status command: {e}")
        await ctx.send("❌ An error occurred while checking API status")

@bot.event
async def on_command_error(ctx, error):
    """Handle command errors"""
    if isinstance(error, commands.CommandNotFound):
        return  # Ignore unknown commands

    logger.error(f"Command error: {error}")
    await ctx.send("❌ An error occurred while executing the command")

def run_discord_bot():
    """Run the Discord bot"""
    if not Config.DISCORD_TOKEN:
        logger.error("Please set DISCORD_TOKEN in your .env file")
        return

    if not Config.DISCORD_CHANNEL_ID:
        logger.error("Please set DISCORD_CHANNEL_ID in your .env file")
        return

    try:
        bot.run(Config.DISCORD_TOKEN)
    except Exception as e:
        logger.error(f"Error running Discord bot: {e}")
    finally:
        # Cleanup
        asyncio.run(stock_notifier.close_session())

if __name__ == "__main__":
    run_discord_bot()
