import time
import logging
import json
import random
from datetime import datetime, timedelta
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
import undetected_chromedriver as uc
from fake_useragent import UserAgent
from retry import retry
import sys
import os

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.config import Config
from database.database_manager import DatabaseManager

class RobloxScraper:
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.driver = None
        self.wait = None
        self.is_logged_in = False
        self.is_in_game = False
        self.last_error_time = None
        self.setup_logging()

    def setup_logging(self):
        """Setup logging configuration"""
        logging.basicConfig(
            level=getattr(logging, Config.LOG_LEVEL),
            format=Config.LOG_FORMAT,
            handlers=[
                logging.FileHandler('logs/scraper.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def init_driver(self):
        """Initialize Chrome driver with anti-detection"""
        try:
            options = uc.ChromeOptions()

            # Add stealth options
            for option in Config.CHROME_OPTIONS:
                options.add_argument(option)

            # Random user agent
            ua = UserAgent()
            options.add_argument(f'--user-agent={ua.random}')

            # Initialize undetected chrome
            self.driver = uc.Chrome(options=options)
            self.wait = WebDriverWait(self.driver, Config.SELENIUM_TIMEOUT)

            self.logger.info("Chrome driver initialized successfully")
            return True

        except Exception as e:
            self.logger.error(f"Failed to initialize driver: {e}")
            return False

    @retry(tries=3, delay=5)
    def login_to_roblox(self):
        """Login to Roblox account"""
        try:
            if not self.driver:
                if not self.init_driver():
                    return False

            self.logger.info("Attempting to login to Roblox...")

            # Navigate to Roblox login
            self.driver.get("https://www.roblox.com/login")
            time.sleep(random.uniform(2, 4))

            # Wait for login form
            username_field = self.wait.until(
                EC.presence_of_element_located((By.ID, "login-username"))
            )
            password_field = self.driver.find_element(By.ID, "login-password")

            # Enter credentials
            username_field.clear()
            username_field.send_keys(Config.ROBLOX_USERNAME)
            time.sleep(random.uniform(0.5, 1))

            password_field.clear()
            password_field.send_keys(Config.ROBLOX_PASSWORD)
            time.sleep(random.uniform(0.5, 1))

            # Click login button
            login_button = self.driver.find_element(By.ID, "login-button")
            login_button.click()

            # Wait for login to complete
            time.sleep(5)

            # Check if login was successful
            if "dashboard" in self.driver.current_url.lower() or "home" in self.driver.current_url.lower():
                self.is_logged_in = True
                self.logger.info("Successfully logged into Roblox")
                return True
            else:
                self.logger.error("Login failed - still on login page")
                return False

        except TimeoutException:
            self.logger.error("Login timeout - page elements not found")
            return False
        except Exception as e:
            self.logger.error(f"Login error: {e}")
            return False

    @retry(tries=3, delay=10)
    def join_game(self):
        """Join Grow a Garden game"""
        try:
            if not self.is_logged_in:
                if not self.login_to_roblox():
                    return False

            self.logger.info("Attempting to join Grow a Garden...")

            # Navigate to game page
            self.driver.get(Config.GAME_URL)
            time.sleep(random.uniform(3, 5))

            # Look for play button
            play_selectors = [
                "button[data-testid='play-button']",
                ".btn-primary-lg",
                ".btn-full-width",
                "button:contains('Play')"
            ]

            play_button = None
            for selector in play_selectors:
                try:
                    play_button = self.wait.until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    break
                except:
                    continue

            if not play_button:
                self.logger.error("Could not find play button")
                return False

            # Click play button
            play_button.click()

            # Wait for game to load
            self.logger.info("Waiting for game to load...")
            time.sleep(30)  # Give game time to load

            # Check if we're in game by looking for game elements
            if self.verify_in_game():
                self.is_in_game = True
                self.logger.info("Successfully joined Grow a Garden")
                return True
            else:
                self.logger.error("Failed to join game")
                return False

        except Exception as e:
            self.logger.error(f"Error joining game: {e}")
            return False

    def verify_in_game(self):
        """Verify that we're actually in the game"""
        try:
            # Look for common game elements
            game_indicators = [
                "canvas",  # Game canvas
                ".game-viewport",
                "#game-viewport",
                "[class*='game']",
                "[id*='game']"
            ]

            for indicator in game_indicators:
                try:
                    element = self.driver.find_element(By.CSS_SELECTOR, indicator)
                    if element:
                        return True
                except:
                    continue

            # Also check URL
            if "games" in self.driver.current_url and "playing" in self.driver.current_url.lower():
                return True

            return False

        except Exception as e:
            self.logger.error(f"Error verifying game state: {e}")
            return False

    def extract_shop_data(self, shop_type):
        """Extract data from a specific shop"""
        try:
            if not self.is_in_game:
                if not self.join_game():
                    return []

            self.logger.info(f"Extracting data from {shop_type} shop...")

            # This is a simplified version - in reality, you'd need to:
            # 1. Navigate to the specific shop NPC
            # 2. Open the shop interface
            # 3. Parse the shop items and their stock levels
            # 4. Handle pagination if needed

            # For now, return mock data based on known items
            return self.get_mock_shop_data(shop_type)

        except Exception as e:
            self.logger.error(f"Error extracting {shop_type} shop data: {e}")
            return []

    def get_mock_shop_data(self, shop_type):
        """Generate mock shop data for testing (replace with real scraping)"""
        mock_data = {
            'seeds': [
                {'name': 'Carrot Seed', 'rarity': 'Common', 'stock': 50, 'price': 10, 'available': True},
                {'name': 'Strawberry Seed', 'rarity': 'Common', 'stock': 45, 'price': 15, 'available': True},
                {'name': 'Grape Seed', 'rarity': 'Divine', 'stock': 2, 'price': 1000, 'available': True},
                {'name': 'Dragon Fruit Seed', 'rarity': 'Mythical', 'stock': 0, 'price': 600, 'available': False},
            ],
            'gear': [
                {'name': 'Watering Can', 'rarity': 'Common', 'stock': 100, 'price': 50, 'available': True},
                {'name': 'Basic Sprinkler', 'rarity': 'Rare', 'stock': 15, 'price': 300, 'available': True},
                {'name': 'Master Sprinkler', 'rarity': 'Divine', 'stock': 1, 'price': 5000, 'available': True},
            ],
            'pets': [
                {'name': 'Common Egg', 'rarity': 'Common', 'stock': 25, 'price': 100, 'available': True},
                {'name': 'Mythical Egg', 'rarity': 'Mythical', 'stock': 3, 'price': 2500, 'available': True},
            ],
            'honey': [
                {'name': 'Lavender Seed', 'rarity': 'Uncommon', 'stock': 20, 'price': 50, 'available': True},
                {'name': 'Hive Fruit Seed', 'rarity': 'Divine', 'stock': 1, 'price': 500, 'available': True},
            ]
        }

        # Add some randomization to make it more realistic
        data = mock_data.get(shop_type, [])
        for item in data:
            # Randomly adjust stock levels
            if item['available']:
                item['stock'] = max(0, item['stock'] + random.randint(-5, 5))
                if item['stock'] == 0:
                    item['available'] = False

        return data

    def detect_weather(self):
        """Detect current weather in game"""
        try:
            if not self.is_in_game:
                return None

            self.logger.info("Detecting current weather...")

            # Mock weather detection - replace with real detection
            weather_types = ['Clear', 'Rain', 'Thunderstorm', 'Frost', 'Night', 'Blood Moon', 'Meteor Shower']
            current_weather = random.choice(weather_types)

            self.logger.info(f"Detected weather: {current_weather}")
            return current_weather

        except Exception as e:
            self.logger.error(f"Error detecting weather: {e}")
            return None

    def run_scraping_cycle(self):
        """Run one complete scraping cycle"""
        try:
            self.logger.info("Starting scraping cycle...")

            # Check all shops
            for shop_type in ['seeds', 'gear', 'pets', 'honey']:
                try:
                    stock_data = self.extract_shop_data(shop_type)
                    if stock_data:
                        self.db_manager.update_stock(shop_type, stock_data)
                        self.logger.info(f"Updated {shop_type} shop data: {len(stock_data)} items")
                    else:
                        self.logger.warning(f"No data extracted for {shop_type} shop")

                    # Random delay between shops
                    time.sleep(random.uniform(2, 5))

                except Exception as e:
                    self.logger.error(f"Error scraping {shop_type} shop: {e}")

            # Check weather
            try:
                current_weather = self.detect_weather()
                if current_weather and current_weather != 'Clear':
                    self.db_manager.add_weather_event(current_weather)

            except Exception as e:
                self.logger.error(f"Error checking weather: {e}")

            self.logger.info("Scraping cycle completed successfully")
            return True

        except Exception as e:
            self.logger.error(f"Error in scraping cycle: {e}")
            return False

    def cleanup(self):
        """Clean up resources"""
        try:
            if self.driver:
                self.driver.quit()
                self.logger.info("Driver cleanup completed")
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")

    def run_continuous(self):
        """Run scraper continuously"""
        self.logger.info("Starting continuous scraping...")

        while True:
            try:
                # Run scraping cycle
                if self.run_scraping_cycle():
                    self.last_error_time = None
                else:
                    self.last_error_time = datetime.now()

                # Calculate next check time
                sleep_time = Config.SCRAPER_DELAY + random.uniform(0, 10)
                self.logger.info(f"Sleeping for {sleep_time:.1f} seconds...")
                time.sleep(sleep_time)

            except KeyboardInterrupt:
                self.logger.info("Scraper stopped by user")
                break
            except Exception as e:
                self.logger.error(f"Unexpected error in continuous loop: {e}")
                time.sleep(60)  # Wait longer on unexpected errors

        self.cleanup()

def main():
    """Main function to run the scraper"""
    # Initialize database
    db_manager = DatabaseManager(Config.DATABASE_PATH)

    # Initialize and run scraper
    scraper = RobloxScraper(db_manager)

    try:
        scraper.run_continuous()
    except KeyboardInterrupt:
        print("\nScraper stopped by user")
    finally:
        scraper.cleanup()

if __name__ == "__main__":
    main()
