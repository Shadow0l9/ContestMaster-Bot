#!/bin/bash
# Grow a Garden Stock Tracker - Startup Script
# This script helps set up and run the application

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install system dependencies
install_system_deps() {
    print_status "Installing system dependencies..."

    if command_exists apt-get; then
        # Ubuntu/Debian
        sudo apt-get update
        sudo apt-get install -y python3 python3-pip python3-venv wget curl

        # Install Chrome
        if ! command_exists google-chrome; then
            print_status "Installing Google Chrome..."
            wget -q -O - https://dl.google.com/linux/linux_signing_key.pub | sudo apt-key add -
            sudo sh -c 'echo "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google-chrome.list'
            sudo apt-get update
            sudo apt-get install -y google-chrome-stable
        fi

    elif command_exists yum; then
        # CentOS/RHEL
        sudo yum update -y
        sudo yum install -y python3 python3-pip wget curl

        print_warning "Please manually install Google Chrome for CentOS/RHEL"

    elif command_exists brew; then
        # macOS
        brew install python3 wget curl
        brew install --cask google-chrome

    else
        print_error "Unsupported operating system. Please install Python 3.8+, pip, and Google Chrome manually."
        exit 1
    fi
}

# Function to set up Python virtual environment
setup_venv() {
    print_status "Setting up Python virtual environment..."

    if [ ! -d "venv" ]; then
        python3 -m venv venv
        print_success "Virtual environment created"
    fi

    source venv/bin/activate
    pip install --upgrade pip
    pip install wheel setuptools
}

# Function to install Python dependencies
install_python_deps() {
    print_status "Installing Python dependencies..."

    if [ ! -f "requirements.txt" ]; then
        print_error "requirements.txt not found!"
        exit 1
    fi

    source venv/bin/activate
    pip install -r requirements.txt
    print_success "Python dependencies installed"
}

# Function to set up configuration
setup_config() {
    print_status "Setting up configuration..."

    if [ ! -f ".env" ]; then
        if [ -f ".env.template" ]; then
            cp .env.template .env
            print_warning "Created .env from template. Please edit it with your credentials:"
            print_warning "  - ROBLOX_USERNAME=your_username"
            print_warning "  - ROBLOX_PASSWORD=your_password"
            print_warning "  - DISCORD_TOKEN=your_bot_token (optional)"
            print_warning "  - DISCORD_CHANNEL_ID=your_channel_id (optional)"
        else
            print_error ".env.template not found!"
            exit 1
        fi
    else
        print_success "Configuration file (.env) already exists"
    fi
}

# Function to create necessary directories
create_directories() {
    print_status "Creating necessary directories..."

    mkdir -p logs
    mkdir -p database

    print_success "Directories created"
}

# Function to test the setup
test_setup() {
    print_status "Testing setup..."

    # Check if .env has required variables
    if [ -f ".env" ]; then
        if grep -q "ROBLOX_USERNAME=" .env && grep -q "ROBLOX_PASSWORD=" .env; then
            # Check if they're not empty (basic check)
            if grep -q "ROBLOX_USERNAME=your_" .env; then
                print_warning "Please update ROBLOX_USERNAME in .env file"
                return 1
            fi
            if grep -q "ROBLOX_PASSWORD=your_" .env; then
                print_warning "Please update ROBLOX_PASSWORD in .env file" 
                return 1
            fi
            print_success "Configuration looks good"
        else
            print_error "Missing required configuration in .env file"
            return 1
        fi
    else
        print_error ".env file not found"
        return 1
    fi

    return 0
}

# Function to run the application
run_app() {
    print_status "Starting Grow a Garden Stock Tracker..."

    if ! test_setup; then
        print_error "Setup test failed. Please fix configuration issues."
        exit 1
    fi

    source venv/bin/activate
    python main.py
}

# Function to run only the API server
run_api() {
    print_status "Starting API server only..."

    source venv/bin/activate
    python api/api_server.py
}

# Function to run only the scraper
run_scraper() {
    print_status "Starting scraper only..."

    if ! test_setup; then
        print_error "Setup test failed. Please fix configuration issues."
        exit 1
    fi

    source venv/bin/activate
    python scrapers/roblox_scraper.py
}

# Function to run the Discord bot
run_discord() {
    print_status "Starting Discord bot..."

    source venv/bin/activate
    python examples/discord_bot.py
}

# Function to test the API
test_api() {
    print_status "Testing API endpoints..."

    source venv/bin/activate
    python test_api.py
}

# Function to show usage
show_usage() {
    echo "Grow a Garden Stock Tracker - Startup Script"
    echo ""
    echo "Usage: $0 [COMMAND]"
    echo ""
    echo "Commands:"
    echo "  setup     - Install dependencies and set up the environment"
    echo "  run       - Run the complete application (API + Scraper)"
    echo "  api       - Run only the API server"
    echo "  scraper   - Run only the scraper"
    echo "  discord   - Run the Discord bot"
    echo "  test      - Test the API endpoints"
    echo "  help      - Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 setup       # First time setup"
    echo "  $0 run         # Start everything"
    echo "  $0 api         # Just the API for development"
    echo ""
}

# Main script logic
case "${1:-}" in
    "setup")
        print_status "Starting setup process..."
        install_system_deps
        setup_venv
        install_python_deps
        setup_config
        create_directories
        print_success "Setup completed! Don't forget to edit the .env file."
        print_status "Next step: $0 run"
        ;;
    "run")
        run_app
        ;;
    "api")
        run_api
        ;;
    "scraper")
        run_scraper
        ;;
    "discord")
        run_discord
        ;;
    "test")
        test_api
        ;;
    "help"|"--help"|"-h")
        show_usage
        ;;
    "")
        print_error "No command specified."
        show_usage
        exit 1
        ;;
    *)
        print_error "Unknown command: $1"
        show_usage
        exit 1
        ;;
esac
