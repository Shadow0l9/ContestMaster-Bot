import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Database settings
    DATABASE_PATH = 'database/grow_a_garden.db'

    # Roblox settings
    ROBLOX_USERNAME = os.getenv('ROBLOX_USERNAME', '')
    ROBLOX_PASSWORD = os.getenv('ROBLOX_PASSWORD', '')
    GAME_URL = 'https://www.roblox.com/games/126884695634066/Grow-a-Garden'

    # API settings
    API_HOST = '0.0.0.0'
    API_PORT = 5000
    API_DEBUG = False

    # Scraper settings
    SCRAPER_DELAY = 30  # seconds between checks
    MAX_RETRIES = 3
    SELENIUM_TIMEOUT = 30

    # Shop refresh intervals (in minutes)
    SEED_SHOP_INTERVAL = 5
    GEAR_SHOP_INTERVAL = 5
    PET_SHOP_INTERVAL = 30
    HONEY_SHOP_INTERVAL = 30

    # Weather check interval (in minutes)
    WEATHER_CHECK_INTERVAL = 1

    # Logging
    LOG_LEVEL = 'INFO'
    LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

    # Chrome driver settings
    CHROME_OPTIONS = [
        '--no-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--disable-web-security',
        '--disable-features=VizDisplayCompositor',
        '--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ]

    # Rate limiting
    RATE_LIMIT_REQUESTS = 100
    RATE_LIMIT_WINDOW = 3600  # 1 hour

    # Discord settings (for example bot)
    DISCORD_TOKEN = os.getenv('DISCORD_TOKEN', '')
    DISCORD_CHANNEL_ID = os.getenv('DISCORD_CHANNEL_ID', '')

    # API base URL for discord bot
    API_BASE_URL = 'http://localhost:5000/api'
