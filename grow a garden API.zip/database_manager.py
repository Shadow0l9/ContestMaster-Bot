import sqlite3
import logging
from datetime import datetime
from pathlib import Path

class DatabaseManager:
    def __init__(self, db_path):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.init_database()

    def init_database(self):
        """Initialize database with all required tables"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                # Create stocks table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS stocks (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        shop_type TEXT NOT NULL,
                        item_name TEXT NOT NULL,
                        item_rarity TEXT,
                        stock_count INTEGER,
                        price INTEGER,
                        currency TEXT DEFAULT 'coins',
                        is_available BOOLEAN DEFAULT 1,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                ''')

                # Create weather table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS weather (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        weather_type TEXT NOT NULL,
                        start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                        end_time DATETIME,
                        duration_minutes INTEGER,
                        mutations_applied TEXT,
                        is_active BOOLEAN DEFAULT 1
                    )
                ''')

                # Create shop_refresh table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS shop_refresh (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        shop_type TEXT NOT NULL,
                        last_refresh DATETIME DEFAULT CURRENT_TIMESTAMP,
                        next_refresh DATETIME,
                        refresh_interval_minutes INTEGER
                    )
                ''')

                # Create api_logs table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS api_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        endpoint TEXT NOT NULL,
                        method TEXT NOT NULL,
                        ip_address TEXT,
                        user_agent TEXT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        response_status INTEGER
                    )
                ''')

                # Create item_rarities reference table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS item_rarities (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        item_name TEXT UNIQUE NOT NULL,
                        rarity TEXT NOT NULL,
                        shop_type TEXT NOT NULL,
                        base_price INTEGER
                    )
                ''')

                # Insert initial shop refresh data
                cursor.execute('''
                    INSERT OR IGNORE INTO shop_refresh (shop_type, refresh_interval_minutes)
                    VALUES 
                        ('seeds', 5),
                        ('gear', 5),
                        ('pets', 30),
                        ('honey', 30)
                ''')

                # Insert item rarities data
                self._insert_initial_items(cursor)

                conn.commit()
                logging.info("Database initialized successfully")

        except Exception as e:
            logging.error(f"Database initialization error: {e}")
            raise

    def _insert_initial_items(self, cursor):
        """Insert initial item data with rarities"""

        # Seed shop items
        seed_items = [
            ('Carrot Seed', 'Common', 'seeds', 10),
            ('Strawberry Seed', 'Common', 'seeds', 15),
            ('Blueberry Seed', 'Uncommon', 'seeds', 25),
            ('Tomato Seed', 'Rare', 'seeds', 50),
            ('Corn Seed', 'Rare', 'seeds', 60),
            ('Daffodil', 'Rare', 'seeds', 75),
            ('Watermelon Seed', 'Legendary', 'seeds', 150),
            ('Pumpkin Seed', 'Legendary', 'seeds', 200),
            ('Apple Seed', 'Legendary', 'seeds', 180),
            ('Bamboo Seed', 'Legendary', 'seeds', 250),
            ('Coconut Seed', 'Mythical', 'seeds', 500),
            ('Cactus Seed', 'Mythical', 'seeds', 400),
            ('Dragon Fruit Seed', 'Mythical', 'seeds', 600),
            ('Grape Seed', 'Divine', 'seeds', 1000),
            ('Mushroom Seed', 'Divine', 'seeds', 800),
            ('Pepper Seed', 'Divine', 'seeds', 900),
            ('Cacao Seed', 'Divine', 'seeds', 750),
            ('Bean Stalk Seed', 'Prismatic', 'seeds', 2000),
            ('Ember Lily', 'Prismatic', 'seeds', 2500)
        ]

        # Gear shop items
        gear_items = [
            ('Watering Can', 'Common', 'gear', 50),
            ('Recall Wrench', 'Uncommon', 'gear', 100),
            ('Trowel', 'Uncommon', 'gear', 150),
            ('Basic Sprinkler', 'Rare', 'gear', 300),
            ('Advanced Sprinkler', 'Legendary', 'gear', 800),
            ('Godly Sprinkler', 'Mythical', 'gear', 2000),
            ('Lightning Rod', 'Mythical', 'gear', 1500),
            ('Master Sprinkler', 'Divine', 'gear', 5000),
            ('Favourite Tool', 'Divine', 'gear', 4000),
            ('Harvest Tool', 'Divine', 'gear', 3500),
            ('Friendship Pot', 'Divine', 'gear', 4500)
        ]

        # Pet shop items
        pet_items = [
            ('Common Egg', 'Common', 'pets', 100),
            ('Uncommon Egg', 'Uncommon', 'pets', 250),
            ('Rare Egg', 'Rare', 'pets', 500),
            ('Legendary Egg', 'Legendary', 'pets', 1000),
            ('Mythical Egg', 'Mythical', 'pets', 2500),
            ('Bug Egg', 'Rare', 'pets', 400)
        ]

        # Honey shop items
        honey_items = [
            ('Lavender Seed', 'Uncommon', 'honey', 50),
            ('Nectarshade Seed', 'Rare', 'honey', 100),
            ('Flower Seed Pack', 'Rare', 'honey', 150),
            ('Nectarine Seed', 'Mythical', 'honey', 300),
            ('Hive Fruit Seed', 'Divine', 'honey', 500),
            ('Honey Sprinkler', 'Divine', 'honey', 800),
            ('Bee Egg', 'Mythical', 'honey', 400),
            ('Pollen Radar', 'Mythical', 'honey', 350),
            ('Nectar Staff', 'Mythical', 'honey', 450),
            ('Bee Crate', 'Legendary', 'honey', 200),
            ('Honey Comb', 'Common', 'honey', 25),
            ('Bee Chair', 'Rare', 'honey', 75),
            ('Honey Torch', 'Rare', 'honey', 80),
            ('Honey Walkway', 'Legendary', 'honey', 120)
        ]

        all_items = seed_items + gear_items + pet_items + honey_items

        cursor.executemany('''
            INSERT OR IGNORE INTO item_rarities (item_name, rarity, shop_type, base_price)
            VALUES (?, ?, ?, ?)
        ''', all_items)

    def update_stock(self, shop_type, stocks_data):
        """Update stock information for a shop"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                # Clear old stock data for this shop
                cursor.execute('DELETE FROM stocks WHERE shop_type = ?', (shop_type,))

                # Insert new stock data
                for item in stocks_data:
                    cursor.execute('''
                        INSERT INTO stocks (shop_type, item_name, item_rarity, stock_count, 
                                          price, currency, is_available, timestamp, last_updated)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        shop_type,
                        item['name'],
                        item.get('rarity', 'Unknown'),
                        item.get('stock', 0),
                        item.get('price', 0),
                        item.get('currency', 'coins'),
                        item.get('available', True),
                        datetime.now(),
                        datetime.now()
                    ))

                conn.commit()
                logging.info(f"Updated {len(stocks_data)} items for {shop_type} shop")

        except Exception as e:
            logging.error(f"Error updating stock for {shop_type}: {e}")
            raise

    def add_weather_event(self, weather_type, mutations=None):
        """Add a new weather event"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                # End any currently active weather of different type
                cursor.execute('''
                    UPDATE weather SET is_active = 0, end_time = ?
                    WHERE is_active = 1 AND weather_type != ?
                ''', (datetime.now(), weather_type))

                # Check if this weather type is already active
                cursor.execute('''
                    SELECT id FROM weather WHERE weather_type = ? AND is_active = 1
                ''', (weather_type,))

                if not cursor.fetchone():
                    # Insert new weather event
                    cursor.execute('''
                        INSERT INTO weather (weather_type, mutations_applied, is_active)
                        VALUES (?, ?, 1)
                    ''', (weather_type, json.dumps(mutations) if mutations else None))

                conn.commit()
                logging.info(f"Added weather event: {weather_type}")

        except Exception as e:
            logging.error(f"Error adding weather event: {e}")
            raise

    def end_weather_event(self, weather_type):
        """End an active weather event"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                cursor.execute('''
                    UPDATE weather 
                    SET is_active = 0, end_time = ?,
                        duration_minutes = CAST((julianday(?) - julianday(start_time)) * 24 * 60 AS INTEGER)
                    WHERE weather_type = ? AND is_active = 1
                ''', (datetime.now(), datetime.now(), weather_type))

                conn.commit()
                logging.info(f"Ended weather event: {weather_type}")

        except Exception as e:
            logging.error(f"Error ending weather event: {e}")
            raise

    def get_current_stocks(self, shop_type=None):
        """Get current stock information"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                if shop_type:
                    cursor.execute('''
                        SELECT * FROM stocks WHERE shop_type = ?
                        ORDER BY item_rarity, item_name
                    ''', (shop_type,))
                else:
                    cursor.execute('''
                        SELECT * FROM stocks
                        ORDER BY shop_type, item_rarity, item_name
                    ''')

                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in cursor.fetchall()]

        except Exception as e:
            logging.error(f"Error fetching stocks: {e}")
            return []

    def get_current_weather(self):
        """Get current active weather"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                cursor.execute('''
                    SELECT * FROM weather WHERE is_active = 1
                    ORDER BY start_time DESC
                ''')

                columns = [desc[0] for desc in cursor.description]
                weather_data = [dict(zip(columns, row)) for row in cursor.fetchall()]

                return weather_data

        except Exception as e:
            logging.error(f"Error fetching current weather: {e}")
            return []

    def get_weather_history(self, limit=50):
        """Get weather history"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                cursor.execute('''
                    SELECT * FROM weather
                    ORDER BY start_time DESC
                    LIMIT ?
                ''', (limit,))

                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in cursor.fetchall()]

        except Exception as e:
            logging.error(f"Error fetching weather history: {e}")
            return []

    def log_api_request(self, endpoint, method, ip_address, user_agent, status):
        """Log API request for monitoring"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                cursor.execute('''
                    INSERT INTO api_logs (endpoint, method, ip_address, user_agent, response_status)
                    VALUES (?, ?, ?, ?, ?)
                ''', (endpoint, method, ip_address, user_agent, status))

                conn.commit()

        except Exception as e:
            logging.error(f"Error logging API request: {e}")
